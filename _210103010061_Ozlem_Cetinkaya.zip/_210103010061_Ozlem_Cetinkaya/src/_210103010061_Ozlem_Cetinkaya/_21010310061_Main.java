package _210103010061_Ozlem_Cetinkaya;

import java.io.FileNotFoundException;

public class _21010310061_Main {
	public static void main(String[] args) throws FileNotFoundException {

		_21010310061_FST fst = new _21010310061_FST();
		fst.reading_File();
		System.out.println("Lutfen 1. inputu giriniz = ");
		fst.machine_Is_Running();
		System.out.println();
		System.out.println("Lutfen 2. inputu giriniz = ");
		fst.machine_Is_Running();

	}
}
