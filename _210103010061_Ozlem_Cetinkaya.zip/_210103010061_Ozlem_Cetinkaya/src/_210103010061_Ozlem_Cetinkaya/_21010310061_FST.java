package _210103010061_Ozlem_Cetinkaya;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class _21010310061_FST {

	String start_state = "";
	ArrayList<Character> input_alphabet = new ArrayList<>();
	HashMap<String, String> transition_states = new HashMap<>();

	public void reading_File() throws FileNotFoundException {
		File file = new File("FST.txt");
		Scanner scan = new Scanner(file);
		String line = "";
		while (scan.hasNextLine()) {

			line = scan.nextLine();
			if (line.startsWith("Σ")) {
				line = line.replaceAll("Σ = ", "").replaceAll(", ", "");
				for (int i = 1; i < line.length(); i++) {
					if (line.charAt(i) != '}') {
						input_alphabet.add(line.charAt(i));
					}
				}
			}
			if (line.startsWith("δ")) {
				line = scan.nextLine();
				while (line.startsWith("q0") != true) {

					String current_state = line.substring(0, 2);
					String temp = line.replaceAll("\\s+", "").substring(2);

					temp = temp.replaceAll("\\(", "").replaceAll("\\)", "-");
					String[] trans_list = temp.split("-");

					for (int i = 0; i < input_alphabet.size(); i++) {

						transition_states.put(current_state + "," + input_alphabet.get(i), trans_list[i]);
					}
					line = scan.nextLine();
				}
			}
			if (line.startsWith("q0")) {
				start_state = line.replaceAll(" ", "").split("=")[1];
			}
		}
		System.out.println("FST.txt okundu!");
		scan.close();
	}

	public void machine_Is_Running() {

		Scanner scan = new Scanner(System.in);
		String user_input = scan.nextLine();
		ArrayList<String> output = new ArrayList<>();
		String current_state = start_state;
		ArrayList<String> output_states = new ArrayList<>();

		for (int i = 0; i < user_input.length(); i++) {

			for (HashMap.Entry<String, String> entry : transition_states.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				String[] key_parts = key.split(",");
				String[] value_parts = value.split(",");

				if (key_parts[0].equals(current_state) && key_parts[1].equals(String.valueOf(user_input.charAt(i)))) {
					current_state = value_parts[0];
					output.add(value_parts[1]);
					output_states.add(current_state);
					break;
				}

			}

		}

		System.out.print("Cikti= ");
		for (int i = 0; i < output.size(); i++) {
			System.out.print(output.get(i) + ",");
		}
		System.out.println();
		System.out.print("Durumlarin sirasi= " + current_state + "-");
		for (int i = 0; i < output_states.size(); i++) {
			System.out.print(output_states.get(i) + "-");
		}

	}

}
